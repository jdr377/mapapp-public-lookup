import { createHash } from "node:crypto";
import { MerklePath, Script, Transaction } from "@bsv/sdk";

type Row = { txid: string; outputIndex: number; lookupBeef: string; proof: string;
  block: number; position: number; headerHash: string };
type Header = { height: number; hash: string; merkleRoot: string; previousHash: string;
  version: number; bits: number; time: number; nonce: number };
type Snapshot = { checkpoint: { height: number; hash: string }; rows: Row[]; headers: Header[] };
const checkpoint = { height: 976547, hash: "00000000000000000afaa872f5a388580912349ffd49c5525369b338699bb66d" };
const id = (row: Row) => `${row.txid}.${row.outputIndex}`;
const hash = (bytes: string | Uint8Array) => createHash("sha256").update(bytes).digest("hex");
const print = (value: object) => console.log(JSON.stringify(value));

function readHeader(header: Header) {
  const bytes = Buffer.alloc(80);
  bytes.writeUInt32LE(header.version >>> 0, 0);
  Buffer.from(header.previousHash, "hex").reverse().copy(bytes, 4);
  Buffer.from(header.merkleRoot, "hex").reverse().copy(bytes, 36);
  bytes.writeUInt32LE(header.time, 68);
  bytes.writeUInt32LE(header.bits, 72);
  bytes.writeUInt32LE(header.nonce, 76);
  return Buffer.from(hash(Buffer.from(hash(bytes), "hex")), "hex").reverse().toString("hex");
}

function describe(row: Row, includeMedia = false) {
  const tx = Transaction.fromBEEF([...Buffer.from(row.lookupBeef, "base64")], row.txid);
  if (tx.id("hex") !== row.txid || !tx.outputs[row.outputIndex]) throw Error("record_subject_mismatch");
  const bytes = tx.outputs[row.outputIndex].lockingScript.toBinary();
  const pushes = bytes[0] === 0 && bytes[1] === 106
    ? Script.fromBinary(bytes.slice(2)).chunks.map(chunk => Buffer.from(chunk.data ?? []).toString("utf8"))
    : [];
  const start = pushes.indexOf("1PuQa7K62MiKCtssSLKy1kh56WWU7MtUR5");
  const fields = new Map<string, string>();
  if (start >= 0 && pushes[start + 1] === "SET") {
    for (let index = start + 2; index + 1 < pushes.length && pushes[index] !== "|"; index += 2) {
      fields.set(pushes[index], pushes[index + 1]);
    }
  }
  const references = [];
  for (const field of ["tx", "afterHide", "previousHide", "targetTxid", "collectionId"]) {
    const value = fields.get(field);
    if (value) references.push({ field, outpoint: value.includes("_") ? value.replace("_", ".") : `${value}.0` });
  }
  if (fields.get("context") === "tx" && fields.get("contextValue")) {
    references.push({ field: "contextValue", outpoint: `${fields.get("contextValue")}.0` });
  }
  const media = fields.get("mediaSha256");
  const embeddedMedia = [];
  if (fields.get("type") === "post" && tx.outputs[1]?.satoshis === 0) {
    const script = tx.outputs[1].lockingScript.toBinary();
    if (script[0] === 0 && script[1] === 106) {
      const [prefix, body, mime, encoding] = Script.fromBinary(script.slice(2)).chunks
        .map(chunk => Buffer.from(chunk.data ?? []));
      const contentType = mime?.toString();
      if (prefix?.toString() === "19HxigV4QyBv3tHpQVcUEQyq1pzZVdoAut" &&
          (contentType === "image/webp" || contentType === "video/webm") &&
          encoding?.toString() === "binary" && body?.length) {
        embeddedMedia.push({ outpoint: `${row.txid}.1`, contentType, bytes: body.length, sha256: hash(body),
          ...(includeMedia ? { base64: body.toString("base64") } : {}) });
      }
    }
  }
  return { tx, record: { outpoint: id(row), block: row.block, position: row.position,
    type: fields.get("context") === "tx" && fields.get("type") === "post" ? "reply" : fields.get("type") ?? null,
    references, ...(media ? { externalMediaSha256: media } : {}),
    ...(fields.has("bapId") ? { targetBapId: fields.get("bapId") } : {}),
    ...(embeddedMedia.length ? { embeddedMedia } : {}) } };
}

function select(rows: Row[], requested: string[]) {
  const available = new Map(rows.map(row => [id(row), row]));
  const selected = new Map<string, Row>();
  const missing = [];
  const queue = [...new Set(requested)];
  for (const outpoint of queue) {
    if (selected.has(outpoint)) continue;
    const row = available.get(outpoint);
    if (!row) { missing.push({ kind: "record", id: outpoint }); continue; }
    selected.set(outpoint, row);
    const { record } = describe(row);
    for (const ref of record.references) if (!queue.includes(ref.outpoint)) queue.push(ref.outpoint);
    if (record.externalMediaSha256) missing.push({ kind: "external_media", id: record.externalMediaSha256 });
    if (record.targetBapId) missing.push({ kind: "public_identity", id: record.targetBapId });
  }
  return { rows: [...selected.values()], missing };
}

const [command, path, ...args] = Bun.argv.slice(2);
try {
  const manifest = await Bun.file(path).json();
  if (hash(manifest.payload) !== manifest.sha256) throw Error("integrity_mismatch");
  const snapshot: Snapshot = JSON.parse(manifest.payload);
  if (snapshot.checkpoint.height !== checkpoint.height || snapshot.checkpoint.hash !== checkpoint.hash) {
    throw Error("checkpoint_mismatch");
  }
  if (command === "list") {
    const [limit = "20", cursor] = args;
    const offset = cursor ? Number(cursor.split(".")[1]) : 0;
    const size = Number(limit);
    if (!Number.isSafeInteger(offset) || offset < 0 || offset > snapshot.rows.length ||
        (cursor && cursor !== `${manifest.sha256}.${offset}`) ||
        !Number.isInteger(size) || size < 1 || size > 100) throw Error("invalid_page");
    const rows = snapshot.rows.slice(offset, offset + size).map(row => describe(row).record);
    const next = offset + rows.length;
    print({ checkpoint, rows, nextCursor: next < snapshot.rows.length ? `${manifest.sha256}.${next}` : null });
  } else if (command === "lookup") {
    const row = snapshot.rows.find(row => id(row) === args[0]);
    print({ checkpoint, record: row ? describe(row).record : null, evidence: row ?? null });
  } else if (command === "export") {
    if (!args.length || args.some(value => !/^[0-9a-f]{64}\.\d+$/.test(value))) throw Error("invalid_selection");
    const requested = [...new Set(args)];
    const selected = select(snapshot.rows, requested);
    const heights = new Set([checkpoint.height, ...selected.rows.map(row => row.block)]);
    const payload = JSON.stringify({ network: "mainnet", policy: "mapapp-publication/v4", checkpoint,
      requested, ...selected, headers: snapshot.headers.filter(header => heights.has(header.height)) });
    print({ format: "mapapp-public-records-export/v1", sha256: hash(payload), payload });
  } else if (command === "verify") {
    const exported = JSON.parse(manifest.payload);
    if (manifest.format !== "mapapp-public-records-export/v1" ||
        exported.network !== "mainnet" || exported.policy !== "mapapp-publication/v4" ||
        !Array.isArray(exported.requested) || !exported.requested.length) throw Error("invalid_export");
    const headers = new Map(snapshot.headers.map(header => [header.height, header]));
    if (headers.get(checkpoint.height)?.hash !== checkpoint.hash ||
        snapshot.headers.some(header => readHeader(header) !== header.hash)) throw Error("invalid_header");
    const records = snapshot.rows.map(row => {
      const { record } = describe(row, true);
      const proof = MerklePath.fromHex(row.proof);
      const leaf = proof.path[0]?.find(item => item.txid && item.hash === row.txid);
      const header = headers.get(row.block);
      if (!header || row.block > checkpoint.height || proof.blockHeight !== row.block ||
          leaf?.offset !== row.position || row.headerHash !== header.hash ||
          proof.computeRoot(row.txid) !== header.merkleRoot) throw Error("invalid_subject_proof");
      return record;
    });
    const selected = select(snapshot.rows, exported.requested);
    if (JSON.stringify(selected.missing) !== JSON.stringify(exported.missing) ||
        JSON.stringify(selected.rows.map(id)) !== JSON.stringify(snapshot.rows.map(id))) {
      throw Error("invalid_dependency_manifest");
    }
    print({ ok: true, complete: selected.missing.length === 0, checkpoint, records, missing: selected.missing });
  } else throw Error("invalid_command");
} catch (error) {
  print({ ok: false, error: error instanceof Error ? error.message : String(error) });
  process.exitCode = 1;
}
