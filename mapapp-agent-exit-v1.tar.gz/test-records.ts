import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

const input = Bun.argv[2];
const work = await mkdtemp(join(tmpdir(), "mapapp-exit-"));
const run = async (command: string, path: string, ...args: string[]) => {
  const child = Bun.spawn([process.execPath, new URL("./records.ts", import.meta.url).pathname.replace(/^\/(?=[A-Za-z]:)/, ""),
    command, path, ...args], { stdout: "pipe", stderr: "pipe" });
  const [body, code, stderr] = await Promise.all([new Response(child.stdout).text(), child.exited, new Response(child.stderr).text()]);
  assert.equal(stderr, "");
  return { value: JSON.parse(body), code };
};
const file = join(work, "selected.json");
const seen = new Set<string>();
let cursor: string | null = null;
do {
  const page = await run("list", input, "50", ...(cursor ? [cursor] : []));
  assert.equal(page.code, 0);
  for (const row of page.value.rows) { assert(!seen.has(row.outpoint)); seen.add(row.outpoint); }
  cursor = page.value.nextCursor;
} while (cursor);
assert.equal(seen.size, 175);
assert.equal((await run("list", input, "50", "invalid")).code, 1);
assert.equal((await run("list", join(work, "unavailable.json"))).code, 1);
assert.equal((await run("lookup", input, `${"0".repeat(64)}.0`)).value.record, null);
const freshen = "1f8ff5ff9cdf7e69b140f731051f4d26127eeddb4a675677a2e93d437220aac3.0";
const hide = "25e8215c046aa4cfa08b54db96af0fbd104720f8fde5403b40cedef615997928.0";
assert(seen.has(freshen) && seen.has(hide));
assert.equal((await run("lookup", input, freshen)).value.record.type, "freshen");
const mediaPost = "5bd358a17212d3b4176e56ac8531df75ac95c85c67fc4c2687cc3feeb54a91cd.0";
const bundle = await run("export", input, freshen, hide, mediaPost);
assert.equal(bundle.code, 0);
await Bun.write(file, JSON.stringify(bundle.value));
const opened = await run("verify", file);
assert.equal(opened.code, 0);
assert.equal(opened.value.complete, true);
assert.equal(opened.value.records.length, 5);
const media = opened.value.records.find(row => row.outpoint === mediaPost).embeddedMedia[0];
assert.equal(media.contentType, "image/webp");
const mediaBytes = Buffer.from(media.base64, "base64");
assert.equal(mediaBytes.length, 2814);
assert.equal(createHash("sha256").update(mediaBytes).digest("hex"),
  "102c054cd209f2838e555a95beed765989fa3b94ce1736169b35cffff5ff3ca1");
const partial = await run("export", input, "95bc5178ed55db21ee6d44ec280fe8396875713aa2cd1942ce2c88c5ebacad9d.0");
await Bun.write(join(work, "partial.json"), JSON.stringify(partial.value));
const partialOpened = await run("verify", join(work, "partial.json"));
assert.equal(partialOpened.code, 0);
assert.equal(partialOpened.value.complete, false);
assert(partialOpened.value.missing.some(item => item.id.startsWith("aaf510dc")));
await Bun.write(join(work, "tampered.json"), JSON.stringify({ ...bundle.value, payload: bundle.value.payload + " " }));
assert.equal((await run("verify", join(work, "tampered.json"))).value.error, "integrity_mismatch");
console.log(JSON.stringify({ ok: true, discovered: seen.size, reopened: opened.value.records.length,
  recoveredMediaBytes: mediaBytes.length, unresolvedDependencies: partialOpened.value.missing.length,
  exportSha256: bundle.value.sha256 }));
