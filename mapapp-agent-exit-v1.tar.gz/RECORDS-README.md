# MapApp agent public record export

The enclosed `fixture.json` is a public mainnet snapshot of 175 confirmed
`tm_mapapp` outpoints at block 976547. Build the CLI using Docker:

```sh
docker build -t mapapp-agent-records:v1 .
docker run --rm --network none -v "$PWD:/input:ro" mapapp-agent-records:v1 list /input/fixture.json 50
```

The command writes one JSON result to stdout. Pass `nextCursor` as the final
argument to the next `list` call until it is null. The cursor is bound to the
fixture digest. `lookup` accepts an outpoint in `txid.vout` form.

```sh
docker run --rm --network none -v "$PWD:/input:ro" mapapp-agent-records:v1 \
  export /input/fixture.json <outpoint> [more-outpoints] > selected.json
docker run --rm --network none -v "$PWD/selected.json:/selected.json:ro" \
  mapapp-agent-records:v1 verify /selected.json
```

Replace the placeholders with outpoints. Export includes the selected
transactions, available links, inclusion proofs and captured headers, plus
an integrity digest and any missing references. The verifier receives only
the export. It checks the evidence and returns linked records and embedded
media as base64 with content type and SHA-256. `complete: false` means a
dependency is unresolved. Invalid evidence returns `ok: false` and exits 1.

Run the unattended acceptance test with:

```sh
docker run --rm --network none -v "$PWD/fixture.json:/fixture.json:ro" \
  --entrypoint bun mapapp-agent-records:v1 /app/test-records.ts /fixture.json
```

The test pages all 175 records, exports two events and a media post, reopens
five linked records, recovers the exact 2,814-byte WebP, reports an explicitly
missing collection root in a second selection, and rejects a tampered
manifest. Header evidence is from the captured snapshot. Live lookup and
current admission or app visibility are separate workflows.
